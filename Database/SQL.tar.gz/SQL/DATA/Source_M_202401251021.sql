INSERT INTO opsian.Source_M (source) VALUES
	 ('Base IMPACTS®2.02'),
	 ('NegaOctet V1.00'),
	 ('negaoctet');
